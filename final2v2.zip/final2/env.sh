export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=/home/kali/final2/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PEER0_ORG1_CA=/home/kali/final2/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export PEER0_ORG2_CA=/home/kali/final2/crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt
export ORDERER_ADMIN_TLS_SIGN_CERT=/home/kali/final2/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/signcerts/Admin@example.com-cert.pem
export ORDERER_ADMIN_TLS_PRIVATE_KEY=/home/kali/final2/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/keystore/priv_sk

setGlobals() {
    local USING_ORG=$1

    if [ $USING_ORG -eq 1 ]; then
        export CORE_PEER_LOCALMSPID="Org1MSP"
        export CORE_PEER_ROOTCERT_FILE=$PEER0_ORG1_CA
        export CORE_PEER_MSPCONFIGPATH=/home/kali/final2/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
        export CORE_PEER_ADDRESS=localhost:7051
    #elif [ $USING_ORG -eq 2 ]; then
        #export CORE_PEER_LOCALMSPID="Org2MSP"
        #export CORE_PEER_ROOTCERT_FILE=$PEER0_ORG2_CA
        #export CORE_PEER_MSPCONFIGPATH=/home/kali/final2/crypto-config/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp
        #export CORE_PEER_ADDRESS=localhost:9051
    #else
       # echo "ORG Unknown"
    fi
}


setGlobalsCLI(){

    setGlobals $1
    local USING_ORG=$1
    if [ $USING_ORG -eq 1 ]; then
        export CORE_PEER_ADDRESS=peer0.org1.example.com:7051
    #elif [ $USING_ORG -eq 2 ]; then
        #export CORE_PEER_ADDRESS=peer0.org2.example.com:9051
    #else
        #echo "ORG Unknown"
    fi
}